﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestToolsServices
{
    [TestClass]
    public class UnitTestToolsServices
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
